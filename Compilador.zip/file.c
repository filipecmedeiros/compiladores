/* -*- c-mode -*- */

int main() {
    int x,y,z,a;
    float h;int c;float w,k,a;

    c = 'x'*'2';
    x = y+w;
    w = (5.2/x)+(((y)*8-5)* 7);
    /** /** /*
       teste &% 
    ***/
    

     
    do{
        
        w = w + 1;
        
    }while  (y<10);


    y = x;
    
    while (x>w*8) {
       float y,a;
        w = w +1;
        y = x;
    }

    a = 0;

    if (w != x) 
    {

        p = 10;
    }else
        p = '1';

}


